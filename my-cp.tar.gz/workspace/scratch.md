find n1's
if x,y have same n1, assign n2(x),n2(y) - if clash NO

try n1(z) then n2(z).