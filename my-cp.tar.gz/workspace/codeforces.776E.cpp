//  Created by Vignesh Manoharan

#include <iostream>
#include <vector>
#include <algorithm>
#include <cstdio>
#include <cmath>
#include <map>
#include <queue>
#include <stack>
#include <set>
#include <numeric>

using namespace std;

typedef long long ll;
typedef vector<int> vi;
typedef vector<ll> vll;
typedef pair<int,int> ii;
typedef vector<vi> vvi;
typedef vector<ii> vii;
typedef vector<vii> vvii;

const int INF = 1000000000;
const ll LINF = 1e17;
const double PI =3.141592653589793238;
const int mod=1000000007;
const double eps = 0.000001;

#define F(i,a,n) for(int i=(a);i<(n);i++)

template<typename T,typename TT> ostream& operator<<(ostream &s,pair<T,TT> t) {return s<<"("<<t.first<<","<<t.second<<")";}
template<typename T> ostream& operator<<(ostream &s,vector<T> t){
    for(int i=0;i<(t).size();i++)s<<t[i]<<((i<(t).size()-1)?" ":"");return s; }
template<typename T> ostream& operator<<(ostream &s,set<T> t){for(T x:t) s<<x<<" ";return s; }
template<typename T> istream& operator>>(istream &s,vector<T> &t){
    for(int _i=0;_i<t.size();_i++) s>>t[_i];return s; }

#define pb push_back
#define mp make_pair
#define all(v) v.begin(),v.end()

const int maxn=1000010;
bool primes[maxn];
    
ll phi(ll a){
    if(a==1) return 1;
    int ispr=1;
    F(i,0,maxn) if(primes[i]){
        if(a<i) break;
        if(a%i==0){
            ispr=0;
            a=(a*(i-1))/i;
        }
    }
    if(ispr) return a-1;
    return a;
}

int main(int argc, const char * argv[]) {
    #ifdef LOCAL_TEST
    freopen("input", "r", stdin);
    freopen("output", "w", stdout);
    #endif
    
    F(i,0,maxn) primes[i]=1;
    primes[0]=primes[1]=0;
    F(i,0,maxn) if(primes[i])
        for(int j=2*i;j<maxn;j+=i)
            primes[j]=0;
    
    ll n,k;
    cin>>n>>k;
    
    while(n>1 && k>0){
        // printf("n %lld k %lld\n",n,k);
        if(k%2==0) k--;
        n=phi(n);
        if(n==1){
            // cout<<"done at "<<k;
            break;
        }
        if(k==1) break;
        k-=2;
    }
    // cout<<n<<"\n";
    cout<<(n%mod)<<"\n";
}


