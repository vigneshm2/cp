Checklist
----

ALWAYS Check these before a submission
- Their test cases
- 2 more of your cases - also corner cases
- **Output format**
- **Overflow**
- cout for floats
- Modulo

Maybe check these

- Large? generated test cases
- Large? random cases
- Time limit , complexity
- Memory stuff - allocation, memory limit
- scanf/printf over cin/cout
